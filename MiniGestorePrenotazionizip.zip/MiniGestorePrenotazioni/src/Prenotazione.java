import java.util.UUID;

public class Prenotazione {

    private UUID codiceUnivoco;
    private int numPosti;
    private StatoPrenotazione statoPrenotazione;
    private Preferenza preferenza;

    public Prenotazione(UUID codiceUnivoco, int numPosti, Preferenza preferenza) {
        this.codiceUnivoco = codiceUnivoco;
        this.numPosti = numPosti;
        this.statoPrenotazione = StatoPrenotazione.IN_CORSO;
        this.preferenza = preferenza;
    }

    public UUID getCodiceUnivoco() {
        return codiceUnivoco;
    }

    public void setCodiceUnivoco(UUID codiceUnivoco) {
        this.codiceUnivoco = codiceUnivoco;
    }

    public int getNumPosti() {
        return numPosti;
    }

    public void setNumPosti(int numPosti) {
        this.numPosti = numPosti;
    }

    public StatoPrenotazione getStatoPrenotazione() {
        return statoPrenotazione;
    }

    public void setStatoPrenotazione(StatoPrenotazione statoPrenotazione) {
        this.statoPrenotazione = statoPrenotazione;
    }

    public Preferenza getPreferenza() {
        return preferenza;
    }

    public void setPreferenza(Preferenza preferenza) {
        this.preferenza = preferenza;
    }

    @Override
    public String toString() {
        return "Prenotazione{" +
                "numPosti=" + numPosti +
                ", statoPrenotazione=" + statoPrenotazione +
                ", preferenza=" + preferenza +
                '}';
    }
}
