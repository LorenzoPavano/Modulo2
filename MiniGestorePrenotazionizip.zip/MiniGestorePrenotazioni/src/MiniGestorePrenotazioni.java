import java.util.Arrays;

public class MiniGestorePrenotazioni {

   /* Esercizio Mini Gestore prenotazioni 🛵

    Scrivere un programma in grado di modellare la gestione delle prenotazioni di un ristorante. Il ristorante può ricevere 2 tipi di prenotazione: singola o di gruppo.
    Progettare la classe GestorePrenotazioni a partire da due interi m e n che determinano rispettivamente il numero di posti disponibili all’interno e all’esterno nel ristorante.
    Ad ogni Prenotazione sono associati un codice univoco. Una prenotazione singola può anche esprimere una preferenza tra interno ed esterno, La prenotazione di gruppo, invece, ha anche un attributo che specifica il numero di posti da riservare.

    La classe prevede i seguenti metodi:

            - prenota: data una Prenotazione p in input, se c’è posto nel ristorante viene accettata restituendo true (dando precedenza alla preferenza indicata), altrimenti viene rifiutata restituendo false
            - terminaPrenotazione: data una Prenotazione p in input, termina la prenotazione eliminandola e liberando i posti associati.

    PLUS🏍: Se presenti prenotazioni singole la cui preferenza può ora essere soddisfatta in virtù dei nuovi posti liberi, modificare la prenotazione di conseguenza.
            Esempio: ci sono 2 posti disponibili all’esterno e 2 prenotazioni p1 e p2, entrambe da 2 persone all’esterno; nel momento in cui viene terminata la prenotazione p1, se p2 è ancora in corso, va spostata all’esterno.
- prenotazioniAttualiEsterno: ritorna un array con le attuali prenotazioni per l’esterno del ristorante
- prenotazioniAttualiInterno: ritorna un array con le attuali prenotazioni per l’interno del ristorante


    Potete usare questo codice come test

```
    MiniGestorePrenotazioni miniGestorePrenotazioni =
            new MiniGestorePrenotazioni(3, 5);
    Prenotazione p1 = new PrenotazioneSingola("12", Preferenza.ESTERNO);
    Prenotazione p2 = new PrenotazioneSingola("23", Preferenza.ESTERNO);
    Prenotazione p3 = new PrenotazioneSingola("34", Preferenza.INTERNO);
    Prenotazione p4 = new PrenotazioneSingola("56", Preferenza.ESTERNO);
miniGestorePrenotazioni.prenota(p1);
miniGestorePrenotazioni.prenota(p2);
miniGestorePrenotazioni.prenota(p3);
miniGestorePrenotazioni.prenota(p4);

    Prenotazione[] prenotazioniInternoArray = miniGestorePrenotazioni.prenotazioniAttualiInterno();
    Prenotazione[] prenotazioniEsternoArray = miniGestorePrenotazioni.prenotazioniAttualiEsterno();
    int prenotazioniInterno = 0, prenotazioniEsterno = 0;
//contiamo e togliamo i null se presenti
for (int i = 0; i < prenotazioniInternoArray.length; i++)
            if (prenotazioniInternoArray[i] != null) {
        prenotazioniInterno++;
    }
for (int i = 0; i < prenotazioniEsternoArray.length; i++)
            if (prenotazioniEsternoArray[i] != null) {
        prenotazioniEsterno++;
    }
System.out.println(prenotazioniInterno == 1);
System.out.println(prenotazioniEsterno == 3);
    Prenotazione p5 = new PrenotazioneGruppo("45", 2);
    boolean a  = miniGestorePrenotazioni.prenota(p5);
    prenotazioniInterno = 0;
    prenotazioniEsterno = 0;
//contiamo e togliamo i null se presenti
for (int i = 0; i < prenotazioniInternoArray.length; i++)
            if (prenotazioniInternoArray[i] != null) {
        prenotazioniInterno++;
    }
for (int i = 0; i < prenotazioniEsternoArray.length; i++)
            if (prenotazioniEsternoArray[i] != null) {
        prenotazioniEsterno++;
    }
System.out.println(prenotazioniInterno + prenotazioniEsterno == 5);
    //verifichiamo i posti effettivamente riservati
    int postiTotali = 0;
for (int i = 0; i < prenotazioniInternoArray.length; i++)
            if (prenotazioniInternoArray[i] != null) {
        postiTotali += prenotazioniInternoArray[i].getnPosti();
    }
for (int i = 0; i < prenotazioniEsternoArray.length; i++)
            if (prenotazioniEsternoArray[i] != null) {
        postiTotali += prenotazioniEsternoArray[i].getnPosti();
    }
System.out.println(postiTotali == 6);
    Prenotazione p6 = new PrenotazioneSingola("67", Preferenza.ESTERNO);
    boolean inserita = miniGestorePrenotazioni.prenota(p6);
System.out.println(inserita);
```

    Suggerimento: usate l’ereditarietà*/

    private int m;
    private int n;
    private Prenotazione[] listaPrenotazioni;

    public MiniGestorePrenotazioni(int postiInterno, int postiEsterno) {
        setM(postiInterno);
        setN(postiEsterno);
        this.listaPrenotazioni = new Prenotazione[50];
    }

    public int getM() {
        return m;
    }

    public void setM(int m) {
        if(this.m <= 100 && this.m >=0)
        this.m = m;
        else
            System.out.println("non si puo' settare piu' di 100 posti interni");
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        if(this.n <= 100 && this.n >= 0)
            this.n = n;
        else
            System.out.println("non si puo' settare piu' di 100 posti esterni");

    }

    public Prenotazione[] getListaPrenotazioni() {
        return listaPrenotazioni;
    }

    @Override
    public String toString() {
        return "MiniGestorePrenotazioni{" +
                "m=" + m +
                ", n=" + n +
                ", listaPrenotazioni=" + Arrays.toString(listaPrenotazioni) +
                '}';
    }

    public boolean prenota(Prenotazione p){

        // Se la prenotazione e' gia' stata fatta in precedenza allora non è possibile rifarla
        if(p.getStatoPrenotazione()==StatoPrenotazione.TERMINATA){
            System.out.println("prenotazione gia' terminata");
            return false;
        }
        else{
            for (Prenotazione prenotazione : listaPrenotazioni) {
                if(prenotazione != null && prenotazione.equals(p)){
                    System.out.println("Prenotazione già presente");
                    return false;
                }
            }
            if(p.getPreferenza()==Preferenza.INTERNO && (getM()>=p.getNumPosti())){
                setM(getM()-p.getNumPosti());
                for (int i = 0; i < listaPrenotazioni.length; i++) {
                    if(listaPrenotazioni[i] == null){
                        listaPrenotazioni[i] = p;
                        break;
                    }
                }
                System.out.println("prenotazione accettata");
                return true;
            }
            else if(p.getPreferenza()==Preferenza.ESTERNO && getN()>=p.getNumPosti()){
                setN(getN()-p.getNumPosti());
                for (int i = 0; i < listaPrenotazioni.length; i++) {
                    if(listaPrenotazioni[i] == null){
                        listaPrenotazioni[i] = p;
                        break;
                    }
                }
                System.out.println("prenotazione accettata");
                return true;
            }
            else if(getM()>=p.getNumPosti()){
                setM(getM()-p.getNumPosti());
                for (int i = 0; i < listaPrenotazioni.length; i++) {
                    if(listaPrenotazioni[i] == null){
                        listaPrenotazioni[i] = p;
                        break;
                    }
                }
                System.out.println("prenotazione accettata");
                return true;
            }
            else if(getN()>=p.getNumPosti()){
                setN(getN()-p.getNumPosti());
                for (int i = 0; i < listaPrenotazioni.length; i++) {
                    if(listaPrenotazioni[i] == null){
                        listaPrenotazioni[i] = p;
                        break;
                    }
                }
                System.out.println("prenotazione accettata");
                return true;
            }
            else {
                System.out.println("errore:non ci sono posti o la prenotazione è nulla");
                return false;
            }
        }

    }

    public boolean terminaPrenotazione(Prenotazione p){

        for (int i = 0; i < listaPrenotazioni.length; i++) {  //la lista prenotazioni memorizza le prenotazioni IN_CORSO,
            //è utile per controllare le prenotazioni nel miniGestore
            if(listaPrenotazioni[i].equals(p)){
                if(getM()+p.getNumPosti()<=40){
                    setM(p.getNumPosti()+getM());
                    p.setStatoPrenotazione(StatoPrenotazione.TERMINATA);
                    listaPrenotazioni[i] = null;
                    System.out.println("prenotazione terminata");
                    return true;
                }
                if(getN()+p.getNumPosti()<=20) {
                    setN(p.getNumPosti() + getN());
                    p.setStatoPrenotazione(StatoPrenotazione.TERMINATA);
                    listaPrenotazioni[i] = null;
                    System.out.println("prenotazione terminata");
                    return true;
                }
            }
        }
        return false;
    }

}
