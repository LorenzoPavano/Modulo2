public enum Preferenza {

    INTERNO, ESTERNO

}
