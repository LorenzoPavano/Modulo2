public enum StatoPrenotazione {

    IN_CORSO, TERMINATA
}
