import java.util.Objects;
import java.util.UUID;

public class Prenotazione {

    private UUID codiceUnivoco;
    private int numPosti;
    private StatoPrenotazione statoPrenotazione;
    private Preferenza preferenza;

    public Prenotazione(int numPosti, Preferenza preferenza) {
        this.codiceUnivoco = UUID.randomUUID();
        this.numPosti = numPosti;
        this.statoPrenotazione = StatoPrenotazione.IN_CORSO;
        this.preferenza = preferenza;
    }

    public UUID getCodiceUnivoco() {
        return codiceUnivoco;
    }

    public void setCodiceUnivoco(UUID codiceUnivoco) {
        this.codiceUnivoco = codiceUnivoco;
    }

    public int getNumPosti() {
        return numPosti;
    }

    public void setNumPosti(int numPosti) {
        this.numPosti = numPosti;
    }

    public StatoPrenotazione getStatoPrenotazione() {
        return statoPrenotazione;
    }

    public void setStatoPrenotazione(StatoPrenotazione statoPrenotazione) {
        this.statoPrenotazione = statoPrenotazione;
    }

    public Preferenza getPreferenza() {
        return preferenza;
    }

    public void setPreferenza(Preferenza preferenza) {
        this.preferenza = preferenza;
    }

	@Override
	public String toString() {
		return "Prenotazione [codiceUnivoco=" + codiceUnivoco + ", numPosti=" + numPosti + ", statoPrenotazione="
				+ statoPrenotazione + ", preferenza=" + preferenza + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(codiceUnivoco, numPosti, preferenza, statoPrenotazione);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prenotazione other = (Prenotazione) obj;
		return Objects.equals(codiceUnivoco, other.codiceUnivoco) && numPosti == other.numPosti
				&& preferenza == other.preferenza && statoPrenotazione == other.statoPrenotazione;
	}
	
	

    
}
