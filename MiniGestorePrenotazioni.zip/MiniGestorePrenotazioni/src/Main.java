import java.util.Arrays;
import java.util.UUID;

public class Main {


    static Prenotazione prenotazione1 = new PrenotazioneSingola(UUID.randomUUID(),Preferenza.ESTERNO);
    static Prenotazione prenotazione2 = new PrenotazioneSingola(UUID.randomUUID(),Preferenza.ESTERNO);
    static Prenotazione prenotazione3 = new PrenotazionediGruppo(UUID.randomUUID(),5,Preferenza.ESTERNO);

    static MiniGestorePrenotazioni ristoranteIlValentino = new MiniGestorePrenotazioni(35,15);


    public static void main(String[] args) {
        System.out.println(ristoranteIlValentino.getN());
        System.out.println(ristoranteIlValentino);
        System.out.println(prenotazione1);
        System.out.println(Arrays.toString(ristoranteIlValentino.getListaPrenotazioni()));
        System.out.println(ristoranteIlValentino.prenota(prenotazione3));
        System.out.println(Arrays.toString(ristoranteIlValentino.getListaPrenotazioni()));
        System.out.println(ristoranteIlValentino.prenota(prenotazione2));
        System.out.println(ristoranteIlValentino.terminaPrenotazione(prenotazione3));
        System.out.println(Arrays.toString(ristoranteIlValentino.getListaPrenotazioni()));

        System.out.println(ristoranteIlValentino.prenota(prenotazione3));
        Prenotazione prenotazione4 = new PrenotazionediGruppo(UUID.randomUUID(),22,Preferenza.ESTERNO);
        System.out.println(ristoranteIlValentino.prenota(prenotazione4));
        Prenotazione prenotazione5 = new PrenotazionediGruppo(UUID.randomUUID(),34,Preferenza.INTERNO);
        System.out.println(ristoranteIlValentino.prenota(prenotazione5));
        System.out.println(Arrays.toString(ristoranteIlValentino.getListaPrenotazioni()));
    }


}
