import java.util.UUID;

public class PrenotazionediGruppo extends Prenotazione{


    public PrenotazionediGruppo(int numPosti, Preferenza preferenza) {
        super(numPosti, preferenza);

    }

    @Override
    public String toString() {
        return "PrenotazionediGruppo{ " + super.toString() + " }";
    }
}
