import java.util.UUID;

public class PrenotazionediGruppo extends Prenotazione{


    public PrenotazionediGruppo(UUID codiceUnivoco, int numPosti, Preferenza preferenza) {
        super(codiceUnivoco, numPosti, preferenza);

    }

    @Override
    public String toString() {
        return "PrenotazionediGruppo{ " + super.toString() + " }";
    }
}
