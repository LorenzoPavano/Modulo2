import java.util.UUID;

public class PrenotazioneSingola extends Prenotazione{


    public PrenotazioneSingola(UUID codiceUnivoco, Preferenza preferenza) {
        super(codiceUnivoco,1,preferenza);
    }

    @Override
    public String toString() {
        return "PrenotazioneSingola{ " + super.toString() + " }";
    }
}
