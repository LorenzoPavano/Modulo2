import java.util.UUID;

public class PrenotazioneSingola extends Prenotazione{


    public PrenotazioneSingola(Preferenza preferenza) {
        super(1,preferenza);
    }

    @Override
    public String toString() {
        return "PrenotazioneSingola{ " + super.toString() + " }";
    }
}
